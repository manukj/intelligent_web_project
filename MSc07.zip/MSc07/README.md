# Plant Management 🌱🌿🌻

Welcome to the Plant Management project! This README will guide you through the steps required to run the project successfully.

![plant-management-logo---313901147](https://github.com/manukj/intelligent_web_project/assets/22499119/91a00d0a-29f9-40d6-91b0-1176417acf90)


## Set 1: Installation

1. **Navigate to the Solution Directory:**

   go to solution directory 
   ```
   cd solution
   ```

2. **Install Dependencies:**

   Install the project dependencies by running the following command:
   ```
   npm install
   ```

   This command will install all the necessary packages required to run the project.

## Set 2: Running the Project

1. **Start the Project:**
   
   ```
   npm run start
   ```

2. **Run Tailwind CSS** (optional, its mostly not needed)

   <ins>Open a new terminal, run the following command to simultaneously run Tailwind CSS</ins>
   ```
   npm run tailwind 
   ```


--------------

## Resources : 

Demo Video : https://www.youtube.com/watch?v=KKdRpOBEUZI 

Github link : https://github.com/manukj/intelligent_web_project ( currently this github repo is private, once the deadline for the project is reached we will make it public )
